<form action="#" method="post">
<input type="text" name="n1">
<input type="submit" value="Enviar">
</form>
<?php
$n1 = $_POST['n1'];

function log($a){
    
}

log($n1);
?>