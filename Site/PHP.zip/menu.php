<nav>
<ol>
<li><a href="?pagina=conversor moeda" title="Conv Moed">CONVERSOR MOEDAS</a></li>
<li><a href="?pagina=conversor temp" title="Conv Temp">CONVERSOR TEMPERATURA</a></li>
<li><a href="?pagina=cadastro" title="Cadastro">CADASTRO</a></li>
<li><a href="?pagina=forca" title="Forca">FORCA</a></li>
</ol>
</nav>