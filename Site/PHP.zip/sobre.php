<html>
<head>
<title>Jogo da Forca</title>
</head>
<body>

<form action="IniciaJogo.php" method="post">
    <input type="submit" name="iniciar" value="iniciar">
</form>
    
<?php



?>
</body>
</html>