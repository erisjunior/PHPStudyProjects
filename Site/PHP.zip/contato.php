<h3>Conversor de Temperatura</h3>

<form action="result.php" method="get">
	<label>Temperatura1</label><br>
	<input type="text" name="temperatura1"><br>
	
	<select name="converter">
		<option value="F>C">F > C</option>
		<option value="C>F">C > F</option>
	</select><br>
	<input type="submit" name="ok" value="Converter">
</form>
