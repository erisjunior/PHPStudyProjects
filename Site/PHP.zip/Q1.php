<form action="#" method="post">
<input type="text" name="n1">
<input type="text" name="n2">
<input type="submit" value="Enviar">
</form>
<?php
$n1=$_POST['n1'];
$n2=$_POST['n2'];
$n3=$n1+$n2;

    if($n3>20){
        $n4 = $n3+8;
    } else if($n3<21){
        $n4 = $n3-5;
    } else{
        $n4 = $n3;
    }
    
    echo $n4;
?>